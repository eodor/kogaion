folosti scurtatura F2 ca sa exportati file FreeBasic.ini cu atributele colorizatoruli,modificati si salvati, repornit Shrimp 
creati un folder numit "plugins", unde stocati pluginurile,
bifati "alow plugins", vor fi ncarcate automat la fiecare lansare a lui Shrimp

use F2 shortcut to export FreeBasic.ini files with colorizer attributes, modified and saved, restart Shrimp
create a folder called "plugins", where you store the plugins,
tick "alow plugins", they will be loaded automatically with each release of Shrimp